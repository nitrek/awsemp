<?php
    define('DATABASE_TYPE', 'mysql:');
    define('SERVER', 'rds-server-team-03.ca5qg3gmjo0i.us-west-2.rds.amazonaws.com');
    define('USERNAME', 'team03');
    define('PASSWORD', 'team123456');
    define('DATABASE', 'employeedb');
?>